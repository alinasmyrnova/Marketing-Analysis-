#### Data Source Reference
The online_shopping_session_data.csv was adatped from the Online Shoppers Purchasing Intention Dataset donated to the UC Irvine Machine Learning Repository on 8/30/2018 (DOI: 10.24432/C5F88Q).

`VisitorType` was renamed to `CustomerType`. Only `Returning` and `New` Visitor levels were retained and renamed to `Returning_Customer` and `New_Customer`, respectively. `Revenue` was renamed to `Purchase`. `OperatingSystems`, `Region`, `Browser`, and `TrafficType` were excluded. 
